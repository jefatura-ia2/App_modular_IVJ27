-- tv-ads 1.0.0 · pantallas (cada TV tiene su enlace secreto) y qué anuncios muestra cada una
CREATE TABLE IF NOT EXISTS mod_tv_ads_pantalla (
  id      SERIAL PRIMARY KEY,
  nombre  TEXT NOT NULL UNIQUE,                 -- «Entrada», «Pasillo 1ª planta»…
  token   TEXT NOT NULL UNIQUE,                 -- se guarda su hash (sha256), nunca el token en claro
  activa  BOOLEAN NOT NULL DEFAULT TRUE,
  visto   TIMESTAMPTZ                            -- última vez que la pantalla pidió anuncios
);
CREATE TABLE IF NOT EXISTS mod_tv_ads_anuncio_pantalla (
  anuncio  INT NOT NULL REFERENCES mod_tv_ads_anuncio(id) ON DELETE CASCADE,
  pantalla INT NOT NULL REFERENCES mod_tv_ads_pantalla(id) ON DELETE CASCADE,
  PRIMARY KEY (anuncio, pantalla)
);
-- las pantallas se crean desde la vista de gestión: la app genera el enlace secreto y guarda solo su hash
