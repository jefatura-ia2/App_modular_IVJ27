# Módulo «Panel de TV para anuncios» (tv-ads) · ejemplo del sistema de módulos

Pantallas de TV del centro (entrada, pasillos…) que muestran los anuncios que publica Jefatura de Estudios.
Ejemplo de referencia del formato de paquete descrito en `docs/SISTEMA-MODULOS.md`.

## Contenido
| Ruta | Qué es |
|---|---|
| `module.yaml` | Manifiesto: versión, compatibilidad, permisos (`ver`, `gestionar`), tablas, mosaico y vista pública |
| `migrations/001_crear_tablas.sql`, `002_pantallas.sql` | Tablas `mod_tv_ads_*` (se aplican una vez y quedan registradas) |
| `src/servidor.js` | Rutas `/api/m/tv-ads/…` (código de servidor: el paquete debe ir firmado) |
| `views/gestion.html` | Vista dentro de la app (mosaico «Panel de TV») con el kit visual de la app |
| `views/pantalla.html` | Vista pública de cada TV, con enlace secreto |
| `assets/` | JS, CSS e icono del módulo |

## Empaquetar
```bash
cd ejemplos/modulos && zip -r tv-ads-1.0.0.zip tv-ads -x '*.DS_Store'
bash ../../deploy/firmar-modulo.sh tv-ads-1.0.0.zip      # (fase 4) añade tv-ads/module.sig
```
Instalar: Administración → **Módulos y portada → Instalar ZIP** (con el candado abierto).

## Protección de datos
Los anuncios no deben contener datos personales; la vista pública solo devuelve los anuncios del día de su pantalla.
Desinstalar conserva las tablas; borrar los datos es una acción aparte y confirmada.
