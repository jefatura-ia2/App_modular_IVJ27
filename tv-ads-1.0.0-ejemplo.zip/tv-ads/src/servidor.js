/**
 * tv-ads · rutas del backend. Se monta en /api/m/tv-ads/… DESPUÉS de requiereSesion y de comprobar que el módulo está activo.
 * El instalador solo carga este fichero si el paquete está firmado por el centro (module.sig).
 *
 * Contrato (docs/SISTEMA-MODULOS.md §8): export default async function registrar(ctx)
 *   ctx.ruta.get|post|put|delete(ruta, permiso, handler)  → permiso = 'ver' | 'gestionar' (obligatorio)
 *   ctx.publica.get(ruta, handler)                         → /api/m/tv-ads/publico/… sin sesión (public_views con token)
 *   ctx.db.query(sql, params)                              → solo tablas mod_tv_ads_*
 *   ctx.registrar(accion, detalle)                         → registro de accesos de la app
 *   ctx.ficheros                                           → almacén del módulo (subidas), con tipos y tamaño limitados
 *   ctx.error(mensaje, estado = 400)                       → error con mensaje para el usuario (nunca 401/403)
 */
const ISO = /^\d{4}-\d{2}-\d{2}$/;

export default async function registrar(ctx) {
  const { db } = ctx;

  /* anuncios vigentes (para la vista de gestión y para cualquiera con permiso de ver) */
  ctx.ruta.get('/anuncios', 'ver', async req => {
    const { rows } = await db.query(`SELECT id, titulo, texto, imagen, to_char(desde,'YYYY-MM-DD') AS desde,
      to_char(hasta,'YYYY-MM-DD') AS hasta, segundos, orden, activo FROM mod_tv_ads_anuncio
      WHERE hasta >= CURRENT_DATE - 30 ORDER BY activo DESC, desde, orden`);
    return { anuncios: rows, puedeGestionar: ctx.puede(req.usuario, 'gestionar') };
  });

  ctx.ruta.post('/anuncios', 'gestionar', async req => {
    const a = req.body || {};
    const titulo = String(a.titulo || '').trim().slice(0, 120);
    if (titulo.length < 3) throw ctx.error('Escribe un título');
    if (!ISO.test(a.desde) || !ISO.test(a.hasta) || a.hasta < a.desde) throw ctx.error('Revisa las fechas');
    const { rows: [r] } = await db.query(`INSERT INTO mod_tv_ads_anuncio (titulo, texto, imagen, desde, hasta, segundos, orden, creado_por)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [titulo, String(a.texto || '').slice(0, 600), ctx.ficheros.nombreSeguro(a.imagen), a.desde, a.hasta,
        Math.min(120, Math.max(5, Number(a.segundos) || 12)), Number(a.orden) || 0, req.usuario.nombre || req.usuario.usuario]);
    ctx.registrar('anuncio_crear', 'anuncio ' + r.id);
    return { id: r.id };
  });

  ctx.ruta.delete('/anuncios/:id', 'gestionar', async req => {
    await db.query('UPDATE mod_tv_ads_anuncio SET activo = FALSE WHERE id = $1', [Number(req.params.id)]);
    ctx.registrar('anuncio_retirar', 'anuncio ' + req.params.id);
    return {};
  });

  ctx.ruta.post('/imagenes', 'gestionar', async req => ctx.ficheros.subir(req, { tipos: ['image/jpeg', 'image/png', 'image/webp'], maxMb: 5 }));

  /* vista pública de una TV: solo los anuncios de hoy de ESA pantalla, sin datos de usuarios */
  ctx.publica.get('/pantalla', async req => {
    const p = await ctx.tokenPantalla(req.query.t, 'mod_tv_ads_pantalla');   /* compara el hash en tiempo constante */
    if (!p) return { ok: false, error: 'Enlace de pantalla no válido' };
    await db.query('UPDATE mod_tv_ads_pantalla SET visto = now() WHERE id = $1', [p.id]);
    const { rows } = await db.query(`SELECT a.id, a.titulo, a.texto, a.imagen, a.segundos FROM mod_tv_ads_anuncio a
      LEFT JOIN mod_tv_ads_anuncio_pantalla ap ON ap.anuncio = a.id
      WHERE a.activo AND CURRENT_DATE BETWEEN a.desde AND a.hasta AND (ap.pantalla IS NULL OR ap.pantalla = $1)
      ORDER BY a.orden, a.id`, [p.id]);
    return { ok: true, pantalla: p.nombre, anuncios: rows };
  });
}
