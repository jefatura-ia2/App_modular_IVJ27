/* Pantalla de TV (sin sesión): rota los anuncios de hoy; vuelve a pedirlos cada 5 minutos */
addEventListener('DOMContentLoaded', () => {
  const t = new URLSearchParams(location.search).get('t') || '';
  const caja = document.getElementById('anuncio');
  let lista = [], i = 0;
  const mostrar = () => {
    if (!lista.length) { caja.textContent = ''; return setTimeout(mostrar, 10000); }
    const a = lista[i++ % lista.length];
    caja.replaceChildren();
    const h = document.createElement('h1'); h.textContent = a.titulo; caja.append(h);
    if (a.texto) { const p = document.createElement('p'); p.textContent = a.texto; caja.append(p); }
    setTimeout(mostrar, (a.segundos || 12) * 1000);
  };
  const cargar = () => fetch('../../../api/m/tv-ads/publico/pantalla?t=' + encodeURIComponent(t), { cache: 'no-store' })
    .then(r => r.json()).then(d => { if (d.ok) lista = d.anuncios; }).catch(() => {});
  cargar().then(mostrar); setInterval(cargar, 5 * 60 * 1000);
});
